<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function __construct()
	{
		parent:: __construct();
		$this->load->library('form_validation');
		$this->load->model('User_model');
	}

	public function index()
	{
		$data['news'] = $this->db->get('news')->result_array();
		$data['terbaru'] = $this->User_model->terbaru();

		$this->load->view('user/user_header', $data);
		$this->load->view('user/berita');
		$this->load->view('user/user_footer');
	}

	public function bisnis()
	{
		$data['bisnis'] = $this->db->get_where('news', ['kode_kategori' => 'KTGR/1'])->result_array();
		$data['news'] = $this->User_model->get_news();

		$this->load->view('user/user_header', $data);
		$this->load->view('user/bisnis');
		$this->load->view('user/user_footer');
	}

	public function sport()
	{
		$data['sport'] = $this->db->get_where('news', ['kode_kategori' => 'KTGR/2'])->result_array();
		$data['news'] = $this->User_model->get_news();

		$this->load->view('user/user_header', $data);
		$this->load->view('user/sport');
		$this->load->view('user/user_footer');
	}

	public function lifestyle()
	{
		$data['lifestyle'] = $this->db->get_where('news', ['kode_kategori' => 'KTGR/3'])->result_array();
		$data['news'] = $this->User_model->get_news();

		$this->load->view('user/user_header', $data);
		$this->load->view('user/lifestyle');
		$this->load->view('user/user_footer');
	}

	public function baca_berita()
	{
		$data['id'] = $this->input->get('id');

		$this->load->view('user/user_header', $data);
		$this->load->view('user/baca_berita');
		$this->load->view('user/user_footer');
	}

	public function tulis()
	{
		$this->load->view('user/user_header');
		$this->load->view('user/tulis');
		$this->load->view('user/user_footer');
	}

	public function informasi()
	{
		$this->load->view('user/user_header');
		$this->load->view('user/informasi');
		$this->load->view('user/user_footer');
	}

	public function proses_berita()
	{
		$this->form_validation->set_rules('judul', 'Judul', 'required|trim', [
				'required' => 'Judul harus diisi',
				'trim' => 'Judul tidak boleh kosong',
		]);
		$this->form_validation->set_rules('penulis', 'Penulis', 'required|trim', [
				'required' => 'Penulis harus diisi',
				'trim' => 'Penulis tidak boleh kosong',
		]);
		$this->form_validation->set_rules('kategori', 'Kategori', 'required|trim', [
				'required' => 'Kategori harus diisi',
				'trim' => 'Kategori tidak boleh kosong',
		]);
		$this->form_validation->set_rules('berita', 'Berita', 'required', [
				'required' => 'berita harus diisi',
		]);

		if ($this->form_validation->run() == false) {
			$this->load->view('user/tulis');
		} else {
			
			$gambar = $_FILES['gambar']['name'];

			if ($gambar == '') {
				$error = 'Tidak ada file yang di upload';
			} else {
				$config['allowed_types'] = 'gif|jpg|png|pdf|jpeg';
				$config['max_width'] = '1028';
				$config['max_height'] = '768';
				$config['upload_path'] = './assets/img/berita';
				$config['overwrite'] = true;

				$this->load->library('upload', $config); 

				if (!$this->upload->do_upload('gambar')) {
					$this->session->set_flashdata('message', '
	                <div class="container">
					  <div class="row">
					   <div class="alert alert-danger" role="alert">
					    Ada kesalahan upload gambar
					    </div>
					  </div>  
					</div>
					');
					$this->load->view('user/tulis');
				}else{
					$data = [
						'kode_kategori' => $this->input->post('kategori'),
						'judul' => $this->input->post('judul'),
						'gambar' => $this->upload->data('file_name'),
						'konten' => $this->input->post('berita'),
						'penulis' => $this->input->post('penulis'),
						'date_created' => time(),
					];


					$this->db->insert('news', $data);
					$this->session->set_flashdata('message', '
					<div class="container">
					  <div class="row">
					   <div class="alert alert-success text-center" role="alert">
					     Berhasil Menambahkan berita
					    </div>
					  </div>  
					</div>
					');
					redirect(base_url('user'));
					
				}
			} 
		}
	}
}
