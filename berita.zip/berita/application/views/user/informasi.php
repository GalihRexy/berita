<div class="wrapper bg-costume">

	<div class="container">
		<div class="row">
			<h2 class="text-light bold">Profil</h2>
		</div>
	</div>

	<div class="container">
		<div class="row">
			<div class="card mt-5" style="width: 30rem;">
			  <img class="card-img-top " src="<?= base_url('assets/img/profil/galih1.jpg'); ?>" alt="Card image cap">
			  <div class="card-body">
			    <p class="bold">Nama : Galih Rexy Hakiki</p>
			    <p class="bold">NIM  : C1A160009</p>
			    <p class="bold">Prodi: Teknik Informatika</p>
			    <p class="bold mb-3">Semester : 6</p>
			    <p class="bold">UAS Praktikum Pemrograman Internet</p>
			  </div>
			</div>
		</div>
	</div>

	
</div>