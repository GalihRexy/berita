<!doctype html>
<html lang="en">
  <head>
    <title>BABER - Baca Berita</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />

    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />

    <!-- CSS Files -->
    <link href="<?= base_url('assets/css/bootstrap.min.css'); ?>" rel="stylesheet" />
    <link href="<?= base_url('assets/css/paper-kit.css'); ?>" rel="stylesheet" />

    <!-- CSS Just for demo purpose, don't include it in your project -->
    <!-- Costume CSS -->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/costume.css'); ?>">
    

  </head>
  <body>

<!--    navbar come here          -->
<nav class="navbar navbar-expand-lg bg-primary">

  <?= $this->session->flashdata('message'); ?>

  <div class="container">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#example-navbar" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
      <a class="navbar-brand logo" href="<?= base_url('user/'); ?>">BaBer</a>
      <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
        <li class="nav-item active">
          <a class="nav-link" href="<?= base_url('user/bisnis'); ?>">Bisnis </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?= base_url('user/sport'); ?>">Sport</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?= base_url('user/lifestyle'); ?>">Lifestyle</a>
        </li>
      </ul>
      <form class="form-inline ml-auto">
          <div class="form-group has-white">
            <i class="nc-icon nc-ruler-pencil bold text-light" style="width: 50px;"><a class="bold text-light ml-1" href="<?= base_url('user/tulis'); ?>">Tulis Berita</a></i>
            <i class="nc-icon nc-single-02 ml-3 bold text-light" style="width: 50px;"><a class="bold text-light ml-1" href="<?= base_url('user/informasi'); ?>">Profil</a></i>
          </div>
      </form>
    </div>
  </div>
</nav>


<!-- end navbar  -->