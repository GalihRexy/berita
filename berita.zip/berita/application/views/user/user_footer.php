<nav class="navbar relative-bottom navbar-light bg-primary mt_2">
  <div class="container">
  	<div>
  		<a class="navbar-brand" href="<?= base_url('user/bisnis'); ?>">Bisnis</a>
  		<a class="navbar-brand" href="<?= base_url('user/sport'); ?>">Sport</a>
  		<a class="navbar-brand" href="<?= base_url('user/lifestyle'); ?>">Lifestyle</a>
  	</div>
    <form class="form-inline ml-auto">
          <div class="form-group has-white">
            <p class="text-light">Desained by <b>Galih Rexy Hakiki</b></p>
          </div>
      </form>
  </div>
</nav>
</div>

<!-- Modal Bodies come here -->

<!--   end modal -->

</body>

<!-- Core JS Files -->
<script src="./assets/js/jquery-3.2.1.js" type="text/javascript"></script>
<script src="./assets/js/jquery-ui-1.12.1.custom.min.js" type="text/javascript"></script>
<script src="./assets/js/popper.js" type="text/javascript"></script>
<script src="./assets/js/bootstrap.min.js" type="text/javascript"></script>

<!-- Switches -->
<script src="./assets/js/bootstrap-switch.min.js"></script>

<!--  Plugins for Slider -->
<script src="./assets/js/nouislider.js"></script>

<!--  Plugins for DateTimePicker -->
<script src="./assets/js/moment.min.js"></script>
<script src="./assets/js/bootstrap-datetimepicker.min.js"></script>

<!--  Paper Kit Initialization snd functons -->
<script src="./assets/js/paper-kit.js"></script>
</html>