

<div class="wrapper bg-costume">

    <!-- content come here     -->
<div class="container">
  <div class="row"><h1 class="bold text-light">Tulis Berita Baru</h1></div>
</div>

<?= $this->session->flashdata('message'); ?>

<div class="container">
  <div class="row">

<div class="card card-nav-tabs text-left mt-5 ml-5" style="width: 45rem;">
  <div class="card-header card-header-primary">
  </div>
  <div class="card-body">
    <form action="<?= base_url('user/proses_berita'); ?>" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label for="judul">Judul Berita</label>
        <input type="text" class="form-control" id="judul" name="judul" placeholder="Judul Berita" value="<?= set_value('judul'); ?>">
        <?= form_error('judul', '<small class="text-danger input-group pl-2">', '</small>') ?>
      </div>
      <div class="form-group">
        <label for="penulis">Penulis</label>
        <input type="text" class="form-control" id="penulis" name="penulis" placeholder="Penulis" value="<?= set_value('penulis'); ?>">
        <?= form_error('penulis', '<small class="text-danger input-group pl-2">', '</small>') ?>
      </div>
      <div class="form-group">
        <?php $kategori = set_value('kategori');?>
        <label for="kategori">Kategori</label>
        <select class="form-control" id="kategori" name="kategori">
          <option <?php if($kategori == 'KTGR/1'){ echo 'selected';} ?> value="KTGR/1">Bisnis</option>
          <option <?php if($kategori == 'KTGR/2'){ echo 'selected';} ?> value="KTGR/2">Sport</option>
          <option <?php if($kategori == 'KTGR/3'){ echo 'selected';} ?> value="KTGR/3">Lifestyle</option>
        </select>
      </div>
      <div class="form-group">
        <label for="berita">Berita</label>
        <textarea class="form-control" id="berita" name="berita" rows="5" placeholder="Tulislah berita yang benar adanya. Bukan mencari keuntungan belaka"><?= set_value('berita'); ?></textarea>
        <?= form_error('berita', '<small class="text-danger input-group pl-2">', '</small>') ?>
        <small>Gunakan <b><</b><b>br</b><b>></b> untuk garis baru.</small>
      </div>
      <div class="form-group">
        <label for="gambar">Gambar</label>
        <div class="custom-file"> 
          <input type="file" class="" name="gambar">
        </div>
      </div>

      <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  </div>
</div>
</div>
</div>



