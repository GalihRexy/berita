<div class="wrapper bg-costume">

<div class="container">
	<div class="row">
		<h2 class="text-light bold">Sport</h2>
	</div>
</div>

<div class="container">
<div class="row">
<?php foreach ($sport as $row) : ?>
  <div class="card mt-5 ml-3" style="width: 22rem;">
    <div class="card-body">
    <h4 class="card-title mb-2"><a href="<?= base_url('user/baca_berita?id=').$row['id_berita']; ?>"><?= $row['judul']; ?></a></h4>
    <img class="card-img-top" src="<?= base_url('assets/img/berita/').$row['gambar']; ?>" alt="Gambar">
      <?php $row['konten'] = $this->User_model->limit_words($row['konten'], 15); ?>
      <p class="card-text mt-2"><?= $row['konten']; ?>...</p>
      <a href="<?= base_url('user/baca_berita?id=').$row['id_berita']; ?>" class="btn btn-primary">Selengkapnya</a>
      <hr>
        <?php $format_waktu = date('d/m/Y H:i', $row['date_created']); ?>
        <?php $hari = $this->User_model->hari($row['date_created']); ?>
        <?= $hari.$format_waktu.' WIB'; ?>
    </div>
  </div>
<?php endforeach; ?>
</div>
</div>

<div class="container text-light mb-5">
    <blockquote class="blockquote mb-0 ">
      <p>Membuat publik melek informasi, agar tak mudah termakan fitnah dan caci maki.</p>
      <footer class="blockquote-footer text-light">Najwa Shihab</footer>
    </blockquote>
</div>

<div class="container">
<div class="row">
  <?php for ($i=0; $i < count($news); $i++) : ?> 
    <div class="card card-nav-tabs ml-3" style="width: 22rem;">
      <div class="card-header card-header-warning">
        <?php $kategori = $this->User_model->kategori($news[$i]['kode_kategori']); ?>
        <a href="<?= base_url('user/'); echo $kategori['nama_kategori']; ?>"><?= $kategori['nama_kategori']; ?></a>
      </div>
      <div class="card-body">
      	<img class="card-img-top" src="<?= base_url('assets/img/berita/'); echo $news[$i]['gambar']; ?>" alt="Gambar">
        <h4 class="card-title"><a href="<?= base_url('user/baca_berita?id=').$news[$i]['id_berita']; ?>"><?= $news[$i]['judul']; ?></a></h4>
        <hr>
        <?php $format_waktu = date('d/m/Y H:i', $news[$i]['date_created']); ?>
        <?php $hari = $this->User_model->hari($news[$i]['date_created']); ?>
        <?= $hari.$format_waktu.' WIB'; ?>
      </div>
    </div>
  <?php endfor; ?>
</div>
</div>

</div>