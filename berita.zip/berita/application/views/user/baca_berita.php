

<div class="wrapper bg-costume">

    <!-- content come here     -->
<div class="container">
  <div class="row">
    <?php $berita = $this->User_model->get_berita($id); ?>
    <h1 class="text-light" style="margin-right: 20%;"><?= $berita['judul']; ?></h1>
  </div>
</div>

<div class="container">
  <div class="row">
    <p class="text-light">By : <?= $berita['penulis']; ?></p>
    <?php $format_waktu = date('d/m/Y H:i', $berita['date_created']); ?>
    <?php $hari = $this->User_model->hari($berita['date_created']); ?>
    <p class="text-light ml-1"><?= ' | '.$hari.$format_waktu.' WIB'; ?></p> 
  </div>
</div>

<div class="container">
  <div class="row">
    <img src="<?= base_url('assets/img/berita/'); echo $berita['gambar']; ?>">
  </div>
</div>

<div class="container">
  <div class="row">
    <p class="text-light mt-3 mb-3" style="margin-right: 43%; "><b><?= $berita['penulis'].' - ' ?></b><?= $berita['konten']; ?></p>
  </div>
</div>





