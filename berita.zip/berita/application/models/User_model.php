<?php 

class User_model extends CI_Model
{
	public function kategori($request)
	{
		$result = $this->db->get_where('kategori', ['kode_kategori' => $request])->row_array();

		return $result;
	}

	public function get_berita($request)
	{
		$result = $this->db->get_where('news', ['id_berita' => $request])->row_array();

		return $result;
	}

	public function hari($request)
	{
		$hari = date('N', $request);
		if($hari == 1){
              $hari = 'Senin, ';
              } else if($hari == 2){
                $hari = 'Selasa, ';
              } else if($hari == 3){
                $hari = 'Rabu, ';
              } else if($hari == 4){
                $hari = 'Kamis, ';
              } else if($hari == 5){
                $hari = 'Jum\'at, ';
              } else if($hari == 6){
                $hari = 'Sabtu, ';
              } else {
                $hari = 'Minggu, ';
              }

         return $hari;
	}

	public function terbaru()
	{
		$this->db->from('news');
		$this->db->order_by('id_berita', 'DESC');
		$this->db->limit(3);
		$query = $this->db->get()->result_array(); 

		return $query;
	}

	public function limit_words($string, $word_limit)
	{
    	$words = explode(" ",$string);
    	return implode(" ",array_splice($words,0,$word_limit));
	}

	public function get_news()
	{
		$news = $this->db->get('news')->result_array();
		shuffle($news);

		return $news;
	}
}