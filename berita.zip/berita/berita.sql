-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 24 Nov 2019 pada 08.04
-- Versi Server: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `berita`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `kode_kategori` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_kategori` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`kode_kategori`, `nama_kategori`) VALUES
('KTGR/1', 'Bisnis'),
('KTGR/2', 'Sport'),
('KTGR/3', 'Lifestyle');

-- --------------------------------------------------------

--
-- Struktur dari tabel `news`
--

CREATE TABLE `news` (
  `id_berita` int(11) NOT NULL,
  `kode_kategori` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `judul` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gambar` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `konten` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `penulis` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `news`
--

INSERT INTO `news` (`id_berita`, `kode_kategori`, `judul`, `gambar`, `konten`, `penulis`, `date_created`) VALUES
(2, 'KTGR/3', 'Ketika Sinar Matahari Jadi Cahaya \'Mematikan\'', 'matahari_mematikan.jpg', 'Nadia El Rami bertekad agar anaknya yang berusia tujuh tahun, Mustapha bisa pergi ke sekolah. Bukan soal tak punya biaya, tapi ini perkara lain, Mustapha Redouane tak bisa duduk bersama dengan temannya di bangku biasa. \r\n<br><br>\r\nEl Rami sepakat dengan kepala sekolah bahwa Mustapha diizinkan untuk ada di ruang kelas, tapi hanya jika dia mau duduk di dalam kotak kardus. \r\n<br><br>\r\nMustapha girang bukan kepalang. Dia tahu ide ibunya ini akan membungkam kekhawatiran sekolah tentang kondisi fisiknya, xeroderma pigmentosum (XP). XP adalah sebuah kelainan genetik langka yang membuat dia \'alergi\' dengan sinar matahari. \r\n<br><br>\r\n\r\nDi saat banyak orang mencari sinar matahari, Mustapha malah justru menghindarinya. Kulit dan matanya bakal terbakar jika dia terkena sinar matahari, sama seperti vampir. \r\n<br><br>\r\n\"Bagaimana pun juga, saya benci matahari. Itu membuat saya terluka,\" katanya sambil duduk di pangkuan ibunya, dikutip dari AP. \r\n<br><br>\r\nMustapha, bocah lelaki tujuh tahun ini punya wajah yang penuh dengan bintik-bintik cokelat gelap di seluruh wajahnya. Buat kepala sekolahnya, bintik cokelat ini dianggap sebagai gangguan bagi siswa lainnya. \r\n<br><br>\r\nSampai saat ini dia sudah melakukan 11 kali operasi untuk menghilangkan pertumbuhan kanker di kulitnya. \r\n<br><br>\r\nDia bersama dengan ribuan keluarga lainnya di seluruh dunia berjuang untuk melawan XP. Mereka tak cuma berjuang untuk mencari pengobatan dan perawatan terbaru, tapi di Maroko, mereka juga berjuang untuk mencari pengakuan, bantuan pemerintah, dan juga hak untuk sekolah. \r\n<br><br>\r\nBukan cuma Mustapha yang sulit sekolah. Putri penjahit Said El Mohamadi yang berusia enam tahun pun sulit sekolah. \r\n<br><br>\r\n\"Dia sedih (dengan kondisinya), tapi saya tidak bisa mengambil risiko dengan membawanya ke sekolah di mana tak ada perlindungan untuk mereka,\" katanya. \r\n<br><br>\r\n\"Tapi dia butuh pendidikan.\"\r\n<br><br>\r\nKenneth Kraemer yang meneliti XP di Institut Kesehatan Nasional AS mengungkapkan bahwa kelainan ini lebih sering terjadi di Afrika Utara dibanding dengan negara lainnya. \r\n<br><br>\r\nKelainan ini disebabkan oleh genetik. XP lebih sering terjadi pada populasi yang mengalami inses atau perkawinan antarkerabat. Kraemer mengatakan bahwa anak-anak ini terkena dampak pewarisan dua salinan gen yang saling bermutasi. Studi pemerintah Maroko pada 2016 lalu mengungkapkan bahwa sekitar 15 persen pernikahan yang terjadi di sana adalah pernikahan antara anggota keluarga. \r\n<br><br>\r\nAkibatnya, Fatima El Fatouikai, seorang ahli dermatologi di Rumah Sakit Universitas Ibn Rochd University di Casablanca, Maroko mengungkapkan bahwa penderita XP yang tinggal di negara dengan matahari yang bersinar sepanjang tahun akan membuat mereka jauh lebih rentan mengalami kanker kulit. \r\n<br><br>\r\nPadahal kebanyakan penderita di sana memiliki akses kesehatan yang terbatas, masyarakat pedesaan yang miskin, dan lebih banyak menghabiskan waktu di luar. \r\n<br><br>\r\n\"Kami hanya memiliki pencegahan sebagai cara pengobatan yang mungkin dilakukan. Anak-anak ini harus menghindari bahan mendapat akses paparan sinar matahari yang minimum,\" katanya soal pencegahan Xeroderma pigmentosum (XP) alias alergi sinar matahari. \r\n<br><br>\r\nSetidaknya mereka harus menghindari sinar matahari, mengenakan pakaian pelindung, pelindung wajah, dan tabir surya. ', 'CNN Indonesia', 1565754134),
(3, 'KTGR/1', 'Trump Rayu Jepang Beli Produk Pertanian AS', 'trump_rayu_jepang.jpg', 'Presiden Amerika Serikat (AS) Donald Trump merayu Jepang untuk membeli produk pertanian mereka dalam jumlah besar. Permintaan itu disampaikan langsung oleh Trump kepada Perdana Menteri Jepang Shinzo Abe. \r\n<br><br>\r\nPermintaan dilakukan di tengah peningkatan ketegangan perang dagang antara AS dan China. Mengutip Reuters Selasa (13/8), Trump secara spesifik menyebut produk kedelai dan gandum sebagai produk pertanian yang ditawarkan ke Jepang. \r\n<br><br>\r\nAtas permintaan itu, Jepang mengaku akan mempertimbangkannya.  \r\n<br><br>\r\n\r\nSebelumnya, dua negara telah membuat kesepakatan untuk memperluas perdagangan bilateral pada September silam. Kesepakatan itu, menjembatani perbedaan pendapat terkait tarif impor daging sapi dan otomotif antar dua negara.\r\n<br><br>\r\nNamun, tawaran pembelian produk pertanian itu terpisah dari kesepakatan dagang sebelumnya. \r\n<br><br>\r\nSebagai informasi, ketegangan dagang antara AS dengan China sampai saat ini masih belum menunjukkan tanda akan berakhir. Bahkan ketegangan saat ini makin menjadi.\r\n<br><br>\r\nPeningkatan ketegangan dipicu oleh rencana Trump yang akan mengenakan tarif 10 persen atas impor senilai US$300 miliar asal China. Rencana tersebut dibalas China.\r\n<br><br>\r\nSalah satu pembalasan dilakukan dengan memutuskan untuk menghentikan pembelian produk pertanian asal AS. Kementerian Perdagangan China telah mengonfirmasi keputusan penghentian pembelian produk pertanian AS itu. ', 'CNN Indonesia', 1565756043),
(4, 'KTGR/2', 'Van Dijk: Chelsea Beda Tanpa Hazard', 'Chelsea_Beda_Tanpa_Hazard.jpg', 'Bek Liverpool Virgil van Dijk mengakui ada perubahan permainan dari Chelsea setelah mereka kehilangan Eden Hazard musim ini.\r\n<br><br>\r\nLiverpool bakal menghadapi Chelsea di ajang Piala Super Eropa 2019 di Istanbul, Turki, Rabu (14/8). Bagi kedua tim, trofi Piala Super Eropa bakal jadi cara terbaik untuk memulai kompetisi musim ini.\r\n<br><br>\r\nBila menilik perbandingan kekuatan kedua tim, Liverpool bakal lebih diunggulkan lantaran memiliki materi tim yang tak banyak berubah. Sebaliknya, Chelsea justru kehilangan pemain bintang seperti Eden Hazard dan David Luiz.\r\n<br><br>\r\n\r\nVan Dijk mengakui Hazard punya peran vital di Chelsea, namun menilai The Blues bakal tetap kuat meski tanpa Hazard. Tanpa Hazard, Van Dijk menilai ada perubahan permainan dari Chelsea.\r\n<br><br>\r\n\"Dia adalah pemain berkualitas dan penting bagi Chelsea, namun saya rasa mereka masih memiliki banyak pemain berkualitas.\"\r\n<br><br>\r\n\"Saya rasa kini mereka bermain dengan cara yang sedikit berbeda dibandingkan tahun lalu. Kami akan coba menganalisa permainan mereka,\" ujar Van Dijk seperti dikutip dari Liverpool Echo.\r\n<br><br>\r\nLiverpool mengawali kompetisi musim ini dengan kemenangan 4-1 atas Norwich. Kemenangan itu membuat Liverpool lebih percaya diri menghadapi laga ini.\r\n<br><br>\r\n\"Trofi tersebut adalah trofi yang ingin kami menangkan dan kami akan memberikan segalanya yang bisa kami lakukan,\" kata Van Dijk.\r\n<br><br>\r\nThe Reds akan tampil tanpa Alisson Becker di laga ini tetapi Van Dijk yakin Adrian bisa mengemban tanggung jawab dengan baik di laga nanti.\r\n<br><br>\r\n\"Saya rasa Adrian sudah memainkan banyak laga besar dalam kariernya jadi saya tidak berpikir dia akan merasa gugup,\" ucap Van Dijk. ', 'CNN Indonesia', 1565756419),
(5, 'KTGR/3', 'Pengguna Aplikasi Dompet Digital di Indonesia Naik', 'dompet_digital.jpg', 'Layanan pembayaran dengan dompet digital di Indonesia kini tengah digandrungi masyarakat seiring meningkatnya pemakaian smartphone. Menjamurnya aplikasi pembayaran digital ini memudahkan masyarakat untuk bertransaksi tanpa menggunakan kartu.\r\n<br><br>\r\nSitus meta-search iPrice Grup berkolaborasi dengan perusahaan analisis data App Annie melakukan penelitian terkait aplikasi dompet elektronik paling populer di Indonesia. iPrice Group dan App Annie menggunakan data jumlan unduhan aplikasi dan pengguna aktif bulanan sejak 2017.\r\n<br><br>\r\nData menunjukkan Gopay, dompet digital perusahaan ride-hailing Gojek menjadi aplikasi dengan pengguna aktif terbanyak di Indonesia.\r\n<br><br>\r\nDihimpun dari laman Medium, 30 persen dari total transaksi uang elektronik di Indonesia berasal dari Gopay. Bahkan pada Februari lalu, Gopay berhasil menyentuh angka transaksi sebesar US$6,3 miliar dengan total 70 persen didapatkan dari transaksi Gojek menggunakan Gopay sebagai metode pembayaran.\r\n\r\n<br><br>\r\nSelain Gopay, sebagai pendatang baru di industri dompet digital, DANA berhasil masuk ke dalam daftar aplikasi dompet digital populer. Data riset iPrice menunjukkan bahwa DANA memiliki pengguna aktif bulanan yang relatif stabil sejak kuartal keempat 2018 hingga kuartal kedua 2019.\r\n<br><br>\r\n\"Dana berhasil naik satu peringkat pada kuartal 2 2019 menggantikan LinkAja di posisi ketiga. Berbeda dengan jumlah download aplikasi, DANA turun satu peringkat ke posisi 3 digantikan oleh OVO pada kuartal 2 2019,\" kata Perwakilan iPrice Grup dikutip keterangan resmi yang diterima CNNIndonesia.com, Selasa (13/8).\r\n<br><br>\r\nAplikasi dompet elektronik milik Lippo Group, OVO bertengger di posisi kedua berdasarkan jumlah unduhan aplikasi di kuartal kedua 2019. Pada sektor transportasi, OVO melebarkan sayap sebagai metode pembayaran di Grab Indonesia.\r\n<br><br>\r\nOVO juga menggaet ecommerce lokal, yakni Tokopedia dengan OVO Cash. Sayangnya, dilihat dari grafik perkembangan OVO di iPrice, jumlah unduhan aplikasi sempat menurun dari peringkat kedua ke peringkat ketiga di kuartal pertama 2018 namun untuk pengguna aktif bulanan naik satu peringkat di periode yang sama.\r\n<br><br>\r\nSalah satu faktor pengguna OVO bertambah dipicu kerjasama antara perusahaan dengan Lion Air Group.\r\n<br><br>\r\nLinkAja resmi menjadi pesaing Gopay dan OVO dengan total 22 juta pengguna yang terdaftar. Aplikasi ini merupakan gabungan dari perusahaan yang ada di dalam Badan Usaha Milik Negara (BUMN) seperti Telkomsel, Bank Mandiri, BNI, Telkom, dan BRI.\r\n<br><br>\r\niPrice mencatat LinkAja bertahan di posisi ketiga dari kuartal kedua 2018 hingga kuartal pertama 2019. Untuk data jumlah unduhan aplikasi, terjadi penurunan pada kuartal keempat 2018.', 'CNN Indonesia', 1565757537),
(6, 'KTGR/1', 'Produksi Pabrik di China Terpukul, Sentuh Level Terendah', 'pabrik_cina_terpukul.jpeg', 'Perlambatan ekonomi China semakin terang benderang. Buktinya, produksi pabrik-pabrik di China terpukul, bahkan menyentuh level terendahnya dalam 17 tahun terakhir ini.\r\n<br><br>\r\nData resmi China melansir ekonomi terbesar kedua di dunia itu terpukul tensi perang dagang dengan AS yang semakin meningkat. Akibatnya, permintaan global lesu yang berdampak terhadap aktivitas pabrik di China. \r\n<br><br>\r\nTercatat, produksi pabrik China bertumbuh 4,8 persen pada Juli 2019. Realisasi itu anjlok dibandingkan 6,3 persen pada bulan sebelumnya. Perlambatan tersebut menandai laju terlemah sejak 2002 silam. \r\n<br><br>\r\nBahkan, jauh dari perkiraan para ekonom dan analis yang disurvei Bloomberg News, dikutip dari AFP, Rabu (14/8). \r\n<br><br>\r\n\"Mengingat lingkungan eksternal yang rumit dan serius, dan tekanan yang meningkat pada ekonomi dalam negeri, fondasi untuk pertumbuhan ekonomi yang berkelanjutan masih perlu dikonsolidasikan,\" ujar Juru Bicara Statistik Nasional China Liu Aihua. \r\n<br><br>\r\nPenjualan ritel, yang selama ini menjadi titik terang bagi ekonomi China, melambat jadi 7,6 persen per Juli. Padahal, penjualan ritel pada Juni 2019 menyentuh 9,8 persen. \r\n<br><br>\r\nSelain ritel, investasi China juga tercatat melambat. Investasi aset tetap meningkat 5,7 persen pada Juli 2019. Padahal, sampai bulan lalu, investasinya masih menyentuh 5,8 persen. \r\n<br><br>\r\nSecara keseluruhan, pertumbuhan ekonomi China menjadi 6,2 persen pada kuartal II 2019, laju terlemah dalam tiga dekade terakhir. \r\n<br><br>\r\nKetidakseimbangan ekonomi China ini membuat Presiden Xi Jinping sulit melawan balik AS, yang menggunakan \'senjata\' mematok tarif impor selangit, untuk memaksa China membuka pasarnya.\r\n<br><br>\r\n\r\n', 'CNN Indonesia', 1565779390),
(7, 'KTGR/3', 'ceritaku', 'images.jpg', 'Ini kisah dari ceritaku', 'Galih', 1567507876),
(8, 'KTGR/3', 'Produksi Pabrik di China Terpukul, Sentuh Level Terendah', 'images.jpg', 'ini kisah dari ceritaku', 'Galih', 1567507969);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`kode_kategori`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id_berita`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id_berita` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
